# Dataset for Image Segmentation 

This repo contains csv file, Training Images, Ground Truth Images (Mask) and helper.py (for visualization)

Dataset Credit : https://github.com/VikramShenoy97/Human-Segmentation-Dataset
